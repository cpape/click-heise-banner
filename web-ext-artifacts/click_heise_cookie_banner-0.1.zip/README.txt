
Clicks the Heise cookie agreement banner.

For my personal use; use on your own risk.

This is a Firefox (>=72) plugin.
